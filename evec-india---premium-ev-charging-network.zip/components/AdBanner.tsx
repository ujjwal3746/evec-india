
import React from 'react';

interface AdBannerProps {
  type: 'leaderboard' | 'rectangle' | 'sidebar';
  label?: string;
}

const AdBanner: React.FC<AdBannerProps> = ({ type, label = "Advertisement" }) => {
  const styles = {
    leaderboard: "w-full h-24 md:h-32 mb-8",
    rectangle: "w-full h-64 mb-6",
    sidebar: "w-full h-[600px] mb-6",
  };

  return (
    <div className={`${styles[type]} glass-morphism rounded-xl flex flex-col items-center justify-center relative overflow-hidden group border border-dashed border-slate-600`}>
      <span className="absolute top-2 left-2 text-[10px] uppercase tracking-widest text-slate-500 font-bold">
        {label}
      </span>
      <div className="flex flex-col items-center gap-2">
        <div className="w-12 h-12 rounded-full bg-slate-800 flex items-center justify-center group-hover:scale-110 transition-transform">
          <i className="fas fa-ad text-blue-400 text-xl"></i>
        </div>
        <p className="text-sm text-slate-400 font-medium">Google AdMob Placement</p>
      </div>
      {/* Animated Scan Line */}
      <div className="absolute inset-0 pointer-events-none bg-gradient-to-b from-transparent via-blue-500/5 to-transparent h-1/2 w-full animate-[pulse_3s_infinite]"></div>
    </div>
  );
};

export default AdBanner;
