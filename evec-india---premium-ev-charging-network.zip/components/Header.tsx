
import React from 'react';

const Header: React.FC = () => {
  return (
    <header className="sticky top-0 z-50 glass-morphism border-b border-white/5">
      <div className="container mx-auto px-4 max-w-7xl h-20 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 bg-blue-600 rounded-xl flex items-center justify-center shadow-lg shadow-blue-600/20">
            <i className="fas fa-bolt text-white text-xl"></i>
          </div>
          <div className="flex flex-col">
            <span className="text-xl font-black tracking-tighter leading-none text-white">EVEC<span className="text-blue-500">.IN</span></span>
            <span className="text-[10px] text-slate-500 font-bold uppercase tracking-widest leading-none mt-1">India's Elite Network</span>
          </div>
        </div>

        <nav className="hidden md:flex items-center gap-10">
          <a href="#" className="text-sm font-bold text-white hover:text-blue-400 transition-colors uppercase tracking-wider">Stations</a>
          <a href="#" className="text-sm font-bold text-slate-400 hover:text-blue-400 transition-colors uppercase tracking-wider">Trip Planner</a>
          <a href="#" className="text-sm font-bold text-slate-400 hover:text-blue-400 transition-colors uppercase tracking-wider">For Business</a>
          <a href="#" className="text-sm font-bold text-slate-400 hover:text-blue-400 transition-colors uppercase tracking-wider">Support</a>
        </nav>

        <div className="flex items-center gap-4">
          <button className="hidden sm:flex items-center gap-2 px-5 py-2.5 rounded-xl border border-slate-700 text-slate-300 font-bold text-sm hover:bg-slate-800 transition-all">
            Login
          </button>
          <button className="bg-blue-600 hover:bg-blue-500 text-white px-5 py-2.5 rounded-xl font-bold text-sm transition-all shadow-lg shadow-blue-600/20">
            Join Network
          </button>
        </div>
      </div>
    </header>
  );
};

export default Header;
