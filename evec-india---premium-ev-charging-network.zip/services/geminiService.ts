
import { GoogleGenAI } from "@google/genai";
import { SearchResult, ChargingStation } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export async function searchChargingStations(query: string, location?: { latitude: number; longitude: number }): Promise<SearchResult> {
  try {
    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: `Find EV charging stations in India based on this request: "${query}". Provide a detailed list including power capacity and current status if possible.`,
      config: {
        tools: [{ googleMaps: {} }],
        toolConfig: {
          retrievalConfig: {
            latLng: location ? {
              latitude: location.latitude,
              longitude: location.longitude
            } : undefined
          }
        }
      },
    });

    const text = response.text || "No detailed description available.";
    const chunks = response.candidates?.[0]?.groundingMetadata?.groundingChunks || [];
    
    // Extract sources from grounding chunks
    const sources = chunks
      .filter((chunk: any) => chunk.maps)
      .map((chunk: any) => ({
        title: chunk.maps.title,
        url: chunk.maps.uri
      }));

    // In a real app, we would parse the AI text or use a structured schema.
    // Since googleMaps tool doesn't support responseSchema, we simulate structured data
    // based on the grounding chunks found.
    const stations: ChargingStation[] = sources.map((source, index) => ({
      id: `station-${index}`,
      name: source.title,
      location: "Verified via Google Maps",
      type: "CCS2 / Type 2",
      power: "50kW - 120kW DC Fast",
      availability: "Available",
      rating: 4.5,
      url: source.url
    }));

    return { text, stations, sources };
  } catch (error) {
    console.error("Gemini Search Error:", error);
    throw error;
  }
}
